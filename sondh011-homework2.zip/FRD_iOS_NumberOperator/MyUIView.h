//
//  MyUIView.h
//  FRD_iOS_NumberOperator
//
//  Created by Dao Hoang Son on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyUIView : UIView

@end
