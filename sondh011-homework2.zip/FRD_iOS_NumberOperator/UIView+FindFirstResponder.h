//
//  UIView+FindFirstResponder.h
//  FRD_iOS_NumberOperator
//
//  Created by Dao Hoang Son on 11/9/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (FindFirstResponder)

- (UIView*)findFirstResponder;

@end
